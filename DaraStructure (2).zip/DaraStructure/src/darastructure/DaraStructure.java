/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package darastructure;

import java.util.*;

/**
 *
 * @author bayad
 */
public class DaraStructure {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Employee emp = new Employee();		 
		int ID ,workHours ,salary, test;
		String Name,firstDayOfWork,address;
                long phoneNumber;
		while (true)
		{
			System.out.println("\t\t****Welcome to Employee Management System****\n" + "\nEnter a number to choose: \n" + "\t (1) insert new employee record.\n" + "\t (2) Delete an employee record.\n" +"\t (3) display employees' records.\n" + "\t (4) Search.\n" + "\t (5) Update employees record.\n" + "\t (6) Update employees salaries.\n" + "\t (7) Exit the system.\n");
			System.out.print("Enter your choice---> ");
			int Choice ;
                        Scanner key = new Scanner(System.in);
			Choice = key.nextInt();
            switch (Choice) {
                case 1:
                 while(true){
                    System.out.print("Enter employee ID (4 digit)---> ");
                    ID = key.nextInt();
                       if (ID<1000 || ID >9999){
                          System.out.println("Wrong ID please enter 4 digits");
                       }
                       else
                           break;
                 }
                    System.out.print("Enter name of employee---> ");
                    Name = key.next();
                    System.out.print("Enter first day of work---> ");
                    firstDayOfWork = key.next();
                    while(true){
                      System.out.print("Enter phone number(Ex:05xxxxxxxx)---> ");
                        phoneNumber = key.nextLong();
                        if(phoneNumber < 04000000000 || phoneNumber> 1000000000)
                             System.out.println("Wrong phoneNumber,please enter the Right PhoneNumber ");
                        else
                            break;
                    }
                    System.out.print("Enter address---> ");
                    address = key.next();
                    System.out.print("Enter working hours---> ");
                    workHours = key.nextInt();
                    

                    while (workHours < 32)
                    {
                        System.out.println("32 hours are required for every employee.");
                        System.out.print("Enter working hours---> ");
                        workHours = key.nextInt();
                    }
                    System.out.print("Enter employee's salary--> ");
                    salary = key.nextInt();
                    emp.insert(ID, Name, firstDayOfWork, phoneNumber, address, workHours, salary);
                    break;
                case 2:
                    System.out.print("Enter employee record ID to delete---> ");
                    ID = key.nextInt();
                    emp.deleteEmployee(ID);
               //     test = emp.deleteEmployee(ID);
                   /* if (test == 0){
                        System.out.print("00 ");
                    }
                    else if (test == -1){
                         System.out.print("-1 ");
               } */
                    break;
                case 3:
                    emp.displayEmp();
                    break;
                case 4:
                    System.out.print("Enter employee ID---> ");
                    ID = key.nextInt();
                    emp.Search(ID);
                    break;
                case 5:
                    System.out.print("Enter employee ID---> ");
                    ID = key.nextInt();
                    emp.updateEmp(ID);
                    break;
                    
                case 6:
                    emp.updateSalary();
                    break;
                    
                case 7:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice, please try again");
                    break;
            }
		}
		
        }
    }
    
