/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package darastructure;

/**
 *
 * @author bayad
 */
public class Node {
    public int ID;
	public String Name;
	public String firstDay;
	public long phoneNumber;
	public String address;
	public int workHours;
	public int salary;
	public Node next;

   public Node(int ID, String Name,  String firstDay ,long phoneNumber,String address,int workHours,int salary){
    this.ID =ID;
    this.Name =Name;
    this.firstDay =firstDay;
    this.phoneNumber =phoneNumber;
    this.address =address;
    this.workHours =workHours;
    this.salary =salary;
    this.next =null;
            }
   public Node(){
       
   }
}