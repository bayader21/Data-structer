/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package darastructure;

import java.util.Scanner;



/**
 *
 * @author bayad
 */
public class Employee {
   public static Node head;
    public Employee(){
    head = null;
    }
  
    
	public static boolean check(int i)
	{
		if (head == null)
		{
			return false;
		}
		Node check ;
		check = head;
		while (check != null)
		{
			if (check.ID == i)
			{
				return true;
			}
			check = check.next;
		}
		return false;
	}

public  void insert(int ID, String Name, String firstDay, long phoneNumber,String address, int workHours, int salary)
	{
		if (check(ID))
		{
			System.out.println("Employee already exists!");
		}

		Node newEmp = new Node(ID,Name,firstDay,phoneNumber,address,workHours,salary);

		if (head == null || (head.ID >= newEmp.ID))
		{
			newEmp.next = head;
			head = newEmp;
		}

		else
		{
			Node temp = head;
			while (temp.next != null && temp.next.ID <= newEmp.ID)
			{
				temp = temp.next;
			}
			newEmp.next = temp.next;
			temp.next = newEmp;
		}

		System.out.println("insertion was successed");
		
	}
public  void updateEmp(int ID)
	{
		if (!check(ID))
		{
			System.out.println("Employee dose not exists!");
		}
                else{
                   Scanner key =new Scanner(System.in);

                    String Name,  firstDay, address;
                    long phoneNumber;
                    int workHours, salary;
                    System.out.print("Enter name of employee---> ");
                    Name = key.next();
                    System.out.print("Enter first day of work---> ");
                    firstDay = key.next();
                    while(true){
                      System.out.print("Enter phone number(Ex:05xxxxxxxx)---> ");
                        phoneNumber = key.nextLong();
                        if(phoneNumber < 04000000000 || phoneNumber> 1000000000)
                             System.out.println("Wrong phoneNumber,please enter the Right PhoneNumber ");
                        else
                            break;
                    }
                    System.out.print("Enter address---> ");
                    address = key.next();
                    System.out.print("Enter working hours---> ");
                    workHours = key.nextInt();
                    

                    while (workHours < 32)
                    {
                        System.out.println("32 hours are required for every employee.");
                        System.out.print("Enter working hours---> ");
                        workHours = key.nextInt();
                    }
                    System.out.print("Enter employee's salary--> ");
                    salary = key.nextInt();
              Node temp=head;
                while(temp!=null){
                    if(temp.ID==ID){
                          temp.Name=Name;
                          temp.salary=salary;
                          temp.address=address;
                          temp.firstDay=firstDay;
                          temp.workHours=workHours;
                          temp.phoneNumber=phoneNumber;
                    }
                    temp=temp.next;
                }
           }
        }
public  void Search(int key){

		if (head == null)
		{
			System.out.println("No record available!");
			return;
		}
		else
		{
                       System.out.println("--- Employee Information ----");
			Node empSearch = head;
			while (empSearch!=null)
			{
				if (empSearch.ID == key)
				{
					System.out.println("Employee ID:");
					System.out.println(empSearch.ID);
					System.out.println("Employee Name:");
					System.out.println(empSearch.Name);
					System.out.println("First Day of Work:");
					System.out.println(empSearch.firstDay);
					System.out.println("Phone Number:");
					System.out.println(empSearch.phoneNumber);
					System.out.println("Address:");
					System.out.println(empSearch.address);
					System.out.println("Work Hours:");
					System.out.println(empSearch.workHours);
					System.out.println("Salary:");
					System.out.println(empSearch.salary);
					return;
				}
				empSearch = empSearch.next;
			}

			if (empSearch == null)
			{
				System.out.println("this employee ID is not exit!");
			}
		}
	}
public  int deleteEmployee(int keyID)
	{
		Node empNode = head;
		Node temp = null;

		if (empNode != null && empNode.ID == keyID)
		{
			head = empNode.next;
			System.out.println("Employee record deleted successfully!");
			return 0;
		}


		while (empNode != null && empNode.ID != keyID)
		{
			temp = empNode;
			empNode = empNode.next;
		}
		if (empNode == null)
		{
			System.out.println("Employee record does not exist!");
                        return -1;
			
		}
		else
		{
			temp.next = empNode.next;
			System.out.println("Record deleted successfully!");
			return 0;
		}
	}

    /**
     *
     */
    public void displayEmp()
	{
		Node empNode = head;
		if (empNode == null)
		{
			System.out.println("No Employee Record Available");
		}
		else
		{
			System.out.println("--- Employees Information ----");

			while (empNode != null)
			{
					System.out.println("Employee ID:\t\t");
					System.out.println(empNode.ID);
					System.out.println("Employee Name:\t\t");
					System.out.println(empNode.Name);
					System.out.println("First Day of Work:\t");
					System.out.println(empNode.firstDay);
					System.out.println("Phone Number:\t\t");
					System.out.println(empNode.phoneNumber);
					System.out.println("Address:\t\t");
					System.out.println(empNode.address);
					System.out.println("Work Hours:\t\t");
					System.out.println(empNode.workHours);
					System.out.println("Salary:\t\t\t");
					System.out.println(empNode.salary);
					System.out.println("");
				      empNode = empNode.next;
			}
		}
	}
	public  void updateSalary()
	{
		Node empNode = head;
		if (empNode == null)
		{
			System.out.print("The list is empty, no salaries to update\n");
		}
		else
		{

			while (empNode != null)
			{

				if (empNode.workHours > 32)
				{
					int extraHours = empNode.workHours - 32;
					empNode.salary += (extraHours * (empNode.salary * 0.02));
				}
				empNode = empNode.next;
			}
		}
                System.out.println("The Update Salaray went Successfuly");
	}


}